package br.com.alura.screenmatch.calculo;

public interface Classificavel {
    int getClassificacao();




}
